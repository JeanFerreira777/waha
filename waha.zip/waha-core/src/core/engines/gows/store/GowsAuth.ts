export interface GowsAuth {
  address(): string;
  dialect(): string;
}
