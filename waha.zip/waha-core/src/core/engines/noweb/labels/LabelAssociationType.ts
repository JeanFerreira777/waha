export enum LabelAssociationType {
  Chat = 'label_jid',
  Message = 'label_message',
}
