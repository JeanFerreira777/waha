export enum Jid {
  BROADCAST = 'status@broadcast',
}
